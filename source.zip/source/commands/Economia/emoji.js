module.exports = {
    moneda: "<:ecolena:1057351070566858793>"
}