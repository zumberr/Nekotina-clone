const { MessageEmbed } = require('discord.js');
module.exports =  {
    
    name: 'pillow',
    aliases: ['almohada','pillow-fight'],
    description: '¿Alguien dijo guerra de almohadas?',
    category: 'Interaccion',
    usage: '<prefix>pillow [@user/id]',
  
    async run(client, message, args, Discord) { 
 
        var pillow = [

            'https://i.imgur.com/ne1X4DA.gif',
        ]

        let img = message.guild.members.resolve(message.mentions.users.first() || client.users.cache.get(args[0]));
        let ramdonpillow = pillow[Math.floor(Math.random()*pillow.length)]
        let desc

        while (!ramdonpillow || ramdonpillow === null || ramdonpillow === '' || ramdonpillow === undefined) {
                
            ramdonpillow = pillow[Math.floor(Math.random()*pillow.length)]
            
        }

        if (!img || img.id === message.author.id) {
    
            desc = `**${message.author.username}** está peleando solo con las almohadas!!`

        } else if (img.user.bot){
          
            return message.reply({ allowedMentions: { repliedUser: false }, embeds: [
          
                new MessageEmbed()
                .setAuthor({ name: message.author.tag, iconURL: message.author.displayAvatarURL({ dynamic: true}) })
                .setColor('RED')
                .setDescription(`¿Guerra de almohadas conmigo? No gracias :<`)
          
            ]}).catch((e) => console.log('Error al enviar mensaje: '+e))
          
        } else {

            desc = `**${message.author.username}** le tiró un almohadazo a **${img.user.username}**. XD`

        }
            
        const embed = new MessageEmbed()
        .setDescription(desc)
        .setImage(ramdonpillow)
        .setColor('RANDOM')
        .setTimestamp(new Date())
        .setFooter({ text: `${message.guild.name}`, iconURL: message.guild.iconURL() ? message.guild.iconURL({ dynamic: true }) : 'https://i.imgur.com/MNWYvup.gif' })

        message.channel.send({ embeds: [embed] }).catch((e) => console.log('Error al enviar mensaje: '+e))
      
    }

}