const { Collection } = require('mongoose');
const userSchema = require('../../models/userSchema');
const { MessageActionRow, MessageButton, MessageEmbed } = require('discord.js');
module.exports =  {
    
    name: 'marry',
    aliases: [],
    description: 'Contrae matrimonio con algún miembro del servidor. Sólo puedes casarte una única vez.',
    category: 'Interaccion',
    usage: '<prefix>marry <@user/id>',
  
    async run(client, message, args, Discord) { 

        var propuest = [

            'https://i.imgur.com/HkblQWq.gif',

        ]
      
        var acepta = [

            'https://i.imgur.com/6i5zWCx.gif',
            'https://i.imgur.com/oGxLMPH.gif',
          
        ]
      
        var rechaza = [

            'https://i.imgur.com/zklf5zj.gif',
            'https://i.imgur.com/KLwXuDX.gif',
          
        ]
      
        var plantado = [

            'https://i.imgur.com/qrn6T4A.gif',
            'https://i.imgur.com/KLwXuDX.gif',
          
        ]

        let img = message.guild.members.resolve(message.mentions.users.first() || client.users.cache.get(args[0]));
        let ramdonp = propuest[Math.floor(Math.random()*propuest.length)]
        let ramdona = acepta[Math.floor(Math.random()*acepta.length)]
        let ramdonr = rechaza[Math.floor(Math.random()*rechaza.length)]
        let ramdonpl = plantado[Math.floor(Math.random()*plantado.length)]

        while (!ramdonp || ramdonp === null || ramdonp === '' || ramdonp === undefined) {

          ramdonp = propuest[Math.floor(Math.random()*propuest.length)]
          
        }
        
        while (!ramdona || ramdona === null || ramdona === '' || ramdona === undefined) {

          ramdona = acepta[Math.floor(Math.random()*acepta.length)]
          
        }
        
        while (!ramdonr || ramdonr === null || ramdonr === '' || ramdonr === undefined) {

          ramdonr = rechaza[Math.floor(Math.random()*rechaza.length)]
          
        }
        
        while (!ramdonpl || ramdonpl === null || ramdonpl === '' || ramdonpl === undefined) {

          ramdonpl = plantado[Math.floor(Math.random()*plantado.length)]
          
        }
        
        if (!img || img.id === message.author.id) return message.reply({embeds: [
        
            new MessageEmbed()
            .setAuthor({ name: message.author.tag, iconURL: message.author.displayAvatarURL({ dynamic: true}) })
            .setColor('RED')
            .setDescription(`¿Te casarías contigo mismo?`)
      
        ]}).catch((e) => console.log('Error al enviar mensaje: '+e))

        if (img.user.bot) return message.reply({embeds: [
        
            new MessageEmbed()
            .setAuthor({ name: message.author.tag, iconURL: message.author.displayAvatarURL({ dynamic: true}) })
            .setColor('RED')
            .setDescription(`No puedes casarte con un bot! >~<`)
      
        ]}).catch((e) => console.log('Error al enviar mensaje: '+e))

        let usuario1 = await userSchema.findOne({ idusuario: message.author.id })
        let usuario2 = await userSchema.findOne({ idusuario: img.id })

        while(!usuario1){
 
            let user = await userSchema.create({

              idusuario: message.author.id,
              username: message.author.username,

            })

            user.save();
            console.log('Usuario Registrado ===> Id: '+ message.author.id + ' Username: ' + message.author.username)

            usuario1 = await userSchema.findOne({ idusuario: message.author.id })

        }

      while(!usuario2){
 
        let user = await userSchema.create({

          idusuario: img.id,
          username: img.username,

        })

        user.save();
        console.log('Usuario Registrado ===> Id: '+ img.id + ' Username: ' + img.username)

        usuario2 = await userSchema.findOne({ idusuario: img.id })
        
      }

      if(usuario1.marry !== 'Soltero(a)' ){

        let id = await client.users.fetch(usuario1.marry)
        
        if(id.id === img.id) return message.reply({embeds: [
          
          new MessageEmbed()
          .setAuthor({ name: message.author.tag, iconURL: message.author.displayAvatarURL({ dynamic: true}) })
          .setColor('RED')
          .setDescription(`¡Qué lindo(a) eres! Ya estás casado(a) con **`+img.user.username+'** <3')
        
        ]}).catch((e) => console.log('Error al enviar mensaje: '+e))

        else return message.reply({embeds: [
          
          new MessageEmbed()
          .setAuthor({ name: message.author.tag, iconURL: message.author.displayAvatarURL({ dynamic: true}) })
          .setColor('RED')
          .setDescription(`No puedes contraer matrimonio porque estás casado(a) con **`+id.username+'#'+id.discriminator+'**!!!')
        
        ]}).catch((e) => console.log('Error al enviar mensaje: '+e))

      } else {

        if(usuario2.marry !== 'Soltero(a)') return message.reply({embeds: [
          
          new MessageEmbed()
          .setAuthor({ name: message.author.tag, iconURL: message.author.displayAvatarURL({ dynamic: true}) })
          .setColor('RED')
          .setDescription(`No puedes contraer matrimonio porque <@${img.id}> ya está casado(a)!!!`)
        
        ]}).catch((e) => console.log('Error al enviar mensaje: '+e))

      }
   
      message.reply({ allowedMentions: { repliedUser: false}, embeds: [
          
        new MessageEmbed()
          .setColor('RANDOM')
          .setTitle('Propuesta de Matrimonio...')
          .setDescription(img.toString() + "¿Deseas casarte con "+message.author.toString()+" ?")
          .setImage(ramdonp)
          .setTimestamp(new Date())
          .setFooter({ text: `${message.guild.name}`, iconURL: message.guild.iconURL() ? message.guild.iconURL({ dynamic: true }) : 'https://i.imgur.com/MNWYvup.gif' })
        ],
        components: [
          new MessageActionRow().addComponents([
            new MessageButton()
              .setCustomId("accept")
              .setLabel("SI")
              .setStyle("SUCCESS"),
            new MessageButton()
              .setCustomId("deny")
              .setLabel("NO")
              .setStyle("DANGER")
          ])
        ]
      }).then(async m => {
      
        let filter = int => int.isButton() && int.user.id == img.id 
       
        const collector = m.createMessageComponentCollector({ filter, max: 1, maxUsers: 1, maxComponents: 1, time: 60000 });
        
        collector.on("collect", async int => {
          
          int.deferUpdate();
          
          if (int.customId === "accept") {
            
            try {

              let update = await userSchema.findOneAndUpdate({ idusuario: message.author.id },
                {
    
                    marry: img.id
    
                });
  
              update.save();
  
              let update2 = await userSchema.findOneAndUpdate({ idusuario: img.id },
                {
    
                    marry: message.author.id
    
                });
  
              update2.save();

              m.edit({embeds: [
                new MessageEmbed()
                .setColor('RANDOM')
                .setTitle('VIVAN L@S NOVI@S!!')
                .setDescription('Enhorabuena '+img.toString() + " y "+message.author.toString()+". Ahora están casados <3.")
                .setImage(ramdona)
                .setTimestamp(new Date())
                .setFooter({ text: `${message.guild.name}`, iconURL: message.guild.iconURL() ? message.guild.iconURL({ dynamic: true }) : 'https://i.imgur.com/MNWYvup.gif' })
              ], components: []
              }).catch((e) => console.log('Error al enviar mensaje: '+e))
              
            } catch (error) {

              console.log('Error al casarse - '+message.author.id+' y '+img.id+' - Error: '+error)
              return message.reply('Hubo un error interno. Por favor, inténtelo de nuevo.').catch((e) => console.log('Error al enviar mensaje: '+e))
            
            }

          } else if (int.customId === "deny") {
            
            m.edit({embeds: [
              new MessageEmbed()
              .setColor('RANDOM')
              .setDescription(img.toString() + " ha rechazado la propuesta de "+message.author.toString()+" <:emoji_2:1045808346109849661>")
              .setImage(ramdonr)
              .setTimestamp(new Date())
              .setFooter({ text: `${message.guild.name}`, iconURL: message.guild.iconURL() ? message.guild.iconURL({ dynamic: true }) : 'https://i.imgur.com/MNWYvup.gif' })
          ],
              components: []
            }).catch((e) => console.log('Error al enviar mensaje: '+e))
          
          }
        });
  
        collector.on("end", (collected, reason) => {
          
          if(collected < 1) return m.edit({embeds: [
            new MessageEmbed()
            .setColor('RANDOM')
            .setTitle('Propuesta sin Respuesta :c')
            .setDescription(img.toString() + " no ha respondido la propuesta de "+message.author.toString()+" <:emoji_2:1045808346109849661>")
            .setImage(ramdonpl)
            .setTimestamp(new Date())
            .setFooter({ text: `${message.guild.name}`, iconURL: message.guild.iconURL() ? message.guild.iconURL({ dynamic: true }) : 'https://i.imgur.com/MNWYvup.gif' })

          ],components: []
          }).catch((e) => console.log('Error al enviar mensaje: '+e))

          console.log('Razón del término de colección de marry: '+reason)
          
        });
        
      }).catch((e) => console.log('Error al enviar mensaje: '+e))

    }

}