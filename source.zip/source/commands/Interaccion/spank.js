const { MessageEmbed } = require('discord.js');
module.exports =  {
    
    name: 'spank',
    aliases: ['nalgada'],
    description: 'Nalguea a alguien.',
    category: 'Interaccion',
    usage: '<prefix>spank <@user/id>',
  
    async run(client, message, args, Discord) { 
 
        var spank = [

            'https://i.imgur.com/Vd6WiWV.gif',
            'https://i.imgur.com/JokuiHT.gif',
            'https://media.tenor.com/Sp7yE5UzqFMAAAAC/spank-slap.gif',
            'https://media.tenor.com/l_-8WyYoZ0YAAAAd/anime-spank-akebi-chan.gif',
            'https://i.imgur.com/dz4HdxA.gif',
            'https://media.tenor.com/sdSmiixaAj0AAAAC/anime-anime-girl.gif',
        
        ]

        let img = message.guild.members.resolve(message.mentions.users.first() || client.users.cache.get(args[0]));
        let ramdonspank = spank[Math.floor(Math.random()*spank.length)]
    
        if (!img || img.id === message.author.id) {
    
            return message.reply({embeds: [
            
                new MessageEmbed()
                .setAuthor({ name: message.author.tag, iconURL: message.author.displayAvatarURL({ dynamic: true}) })
                .setColor('RED')
                .setDescription(`¿Te quieres autonalguear? O.o`)
          
            ]}).catch((e) => console.log('Error al enviar mensaje: '+e))

        } else if (img.user.bot){
          
            return message.reply({ allowedMentions: { repliedUser: false }, embeds: [
          
                new MessageEmbed()
                .setAuthor({ name: message.author.tag, iconURL: message.author.displayAvatarURL({ dynamic: true}) })
                .setColor('RED')
                .setDescription(`Soy Loli, no puedes hacer eso >~<`)
          
            ]}).catch((e) => console.log('Error al enviar mensaje: '+e))
          
        } else {

            while (!ramdonspank || ramdonspank === null || ramdonspank === '' || ramdonspank === undefined) {
                
                ramdonspank = spank[Math.floor(Math.random()*spank.length)]
                
            }
    
            const embed = new MessageEmbed()
            .setDescription(`**${message.author.username}** le da una rica nalgada a **${img.user.username}** 7w7.`)
            .setImage(ramdonspank ? ramdonspank : null)
            .setColor('RANDOM')
            .setTimestamp(new Date())
            .setFooter({ text: `${message.guild.name}`, iconURL: message.guild.iconURL() ? message.guild.iconURL({ dynamic: true }) : 'https://i.imgur.com/MNWYvup.gif' })

            message.channel.send({ embeds: [embed] }).catch((e) => console.log('Error al enviar mensaje: '+e))
      
        }

    }

}