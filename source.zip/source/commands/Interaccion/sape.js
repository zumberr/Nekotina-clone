const { Collection } = require('mongoose');
const userSchema = require('../../models/userSchema');
const { MessageEmbed } = require('discord.js');
module.exports =  {
    
    name: 'sape',
    aliases: ['sapear'],
    description: 'Dale un sape a alguien',
    category: 'Interaccion',
    usage: '<prefix>sape <@user/id>',
  
    async run(client, message, args, Discord) { 

        var sape = [

          'https://i.imgur.com/e8jyxOd.gif',
            'https://i.imgur.com/ZVHrTdk.gif',
            'https://i.imgur.com/v7oAcQD.gif',
            'https://i.imgur.com/EPZUlyQ.gif',
            'https://i.imgur.com/KXJkWcS.gif',
        
        ]

        let img = message.guild.members.resolve(message.mentions.users.first() || client.users.cache.get(args[0]));
        let ramdonsape = sape[Math.floor(Math.random()*sape.length)]

        while (!ramdonsape || ramdonsape === null || ramdonsape === '' || ramdonsape === undefined) {
          
          ramdonsape = sape[Math.floor(Math.random()*sape.length)]
        
        }

        if (!img || img.id===message.author.id) return message.reply({embeds: [
          
            new MessageEmbed()
            .setAuthor({ name: message.author.tag, iconURL: message.author.displayAvatarURL({ dynamic: true}) })
            .setColor('RED')
            .setDescription(`¿Te darías un autosape? O.o`)
        
        ]}).catch((e) => console.log('Error al enviar mensaje: '+e))

        if (img.user.bot) return message.reply({ allowedMentions: { repliedUser: false}, embeds: [
          
          new MessageEmbed()
          .setAuthor({ name: message.author.tag, iconURL: message.author.displayAvatarURL({ dynamic: true}) })
          .setColor('RED')
          .setDescription(`>~< Ni lo intentes!`)
        
        ]}).catch((e) => console.log('Error al enviar mensaje: '+e))
  
        let usuario2 = await userSchema.findOne({idusuario: img.id})
        let text

        while(!usuario2){
 
          let user = await userSchema.create({

            idusuario: img.id,
            username: img.username,

          })

          user.save();
          console.log('Usuario Registrado ===> Id: '+ img.id + ' Username: ' + img.username)

          usuario2 = await userSchema.findOne({idusuario: img.id})

        }
    
        let update = await userSchema.findOneAndUpdate({idusuario: img.id},
          {

              sape: usuario2.sape + 1
      
          });
          
        update.save()

        if((usuario2.sape + 1) === 1){
          
          text = '**'+(usuario2.sape + 1)+'** sape'
        
        } else{
          
          text = '**'+(usuario2.sape + 1)+'** sapes'
        
        }
          
        const embed = new MessageEmbed()
        .setDescription(`**${message.author.username}** le dió un sape a **${img.user.username}**. >:v \n*${img.user.username}* ha recibido ${text} en total.`)
        .setImage(ramdonsape)
        .setColor('RANDOM')
        .setTimestamp(new Date())
        .setFooter({ text: `${message.guild.name}`, iconURL: message.guild.iconURL() ? message.guild.iconURL({ dynamic: true }) : 'https://i.imgur.com/MNWYvup.gif' })

        message.channel.send({ embeds: [embed] }).catch((e) => console.log('Error al enviar mensaje: '+e))

    }

}