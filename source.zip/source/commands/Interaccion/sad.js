const { MessageEmbed } = require('discord.js');
module.exports =  {
    
    name: 'sad',
    aliases: ['triste','depre'],
    description: 'Mood Sad.',
    category: 'Interaccion',
    usage: '<prefix>sad [@user/id]',
  
    async run(client, message, args, Discord) { 
 
        var sad = [

            'https://i.imgur.com/bE1yLCW.gif',
            ''
        
        ]

        let img = message.guild.members.resolve(message.mentions.users.first() || client.users.cache.get(args[0]));
        let ramdonsad = sad[Math.floor(Math.random()*sad.length)]
    
        while (!ramdonsad || ramdonsad === null || ramdonsad === '' || ramdonsad === undefined) {
            
            ramdonsad = sad[Math.floor(Math.random()*sad.length)]

        }
        
        if (!img || img.id === message.author.id) {
    
            const embed = new MessageEmbed()
            .setDescription(`**${message.author.username}** se puso triste :c`)
            .setImage(ramdonsad)
            .setColor('RANDOM')
            .setTimestamp(new Date())
            .setFooter({ text: `${message.guild.name}`, iconURL: message.guild.iconURL() ? message.guild.iconURL({ dynamic: true }) : 'https://i.imgur.com/MNWYvup.gif' })

            message.channel.send({ embeds: [embed] }).catch((e) => console.log('Error al enviar mensaje: '+e))
    
        } else if (img.user.bot){
          
            return message.reply({ allowedMentions: { repliedUser: false }, embeds: [
          
                new MessageEmbed()
                .setAuthor({ name: message.author.tag, iconURL: message.author.displayAvatarURL({ dynamic: true}) })
                .setColor('RED')
                .setDescription(`¡Yo no ando sad!`)
          
            ]}).catch((e) => console.log('Error al enviar mensaje: '+e))
          
        } else {
    
            const embed = new MessageEmbed()
            .setDescription(`**${message.author.username}** y **${img.user.username}** andan modo sad.`)
            .setImage(ramdonsad)
            .setColor('RANDOM')
            .setTimestamp(new Date())
            .setFooter({ text: `${message.guild.name}`, iconURL: message.guild.iconURL() ? message.guild.iconURL({ dynamic: true }) : 'https://i.imgur.com/MNWYvup.gif' })

            message.channel.send({ embeds: [embed] }).catch((e) => console.log('Error al enviar mensaje: '+e))
      
        }

    }

}