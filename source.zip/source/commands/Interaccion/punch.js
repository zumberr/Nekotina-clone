const { MessageEmbed } = require('discord.js');
module.exports =  {
    
    name: 'punch',
    aliases: ['puñetear','golpear','golpe','puñete'],
    description: 'Tira un golpe a alguien.',
    category: 'Interaccion',
    usage: '<prefix>punch <@user/id>',
  
    async run(client, message, args, Discord) { 

        var punch = [

            'https://i.imgur.com/zORukcc.gif',
            'https://i.imgur.com/J0ChlRO.gif',
            'https://i.imgur.com/BSXviU7.gif',
            'https://i.imgur.com/8vB46zh.gif',
            'https://i.imgur.com/Vqoadcv.gif',
            'https://i.imgur.com/C8kPz2g.gif',
            'https://i.imgur.com/jznCcr2.gif',
            'https://i.imgur.com/hlqNBXp.gif',
            'https://i.imgur.com/AmQvKOV.gif',
            'https://i.imgur.com/tcMa10X.gif',
            'https://i.imgur.com/IY9OgF8.gif',
            'https://i.imgur.com/1jOVFBj.gif',
            'https://i.imgur.com/HlMv0yB.gif',
            'https://i.imgur.com/FSQC52W.gif',

        
        ]

        let img = message.guild.members.resolve(message.mentions.users.first() || client.users.cache.get(args[0]));
        let ramdonpunch = punch[Math.floor(Math.random()*punch.length)]
    
        if (!img || img.id === message.author.id) {
    
            return message.reply({embeds: [
            
                new MessageEmbed()
                .setAuthor({ name: message.author.tag, iconURL: message.author.displayAvatarURL({ dynamic: true}) })
                .setColor('RED')
                .setDescription(`¿Te golpearías a ti mismo? XD`)
          
            ]}).catch((e) => console.log('Error al enviar mensaje: '+e))
    
        } else if (img.user.bot){
          
            return message.reply({ allowedMentions: { repliedUser: false}, embeds: [
          
                new MessageEmbed()
                .setAuthor({ name: message.author.tag, iconURL: message.author.displayAvatarURL({ dynamic: true}) })
                .setColor('RED')
                .setDescription(`>~< Ni lo intentes`)
          
            ]}).catch((e) => console.log('Error al enviar mensaje: '+e))
          
        } else {
    
            while (!ramdonpunch || ramdonpunch === null || ramdonpunch === '' || ramdonpunch === undefined) {
                
                ramdonpunch = punch[Math.floor(Math.random()*punch.length)]

            }
            
            const embed = new MessageEmbed()
            .setDescription(`**${message.author.username}** le dió un puñetazo a **${img.user.username}**.`)
            .setImage(ramdonpunch)
            .setColor('RANDOM')
            .setTimestamp(new Date())
            .setFooter({ text: `${message.guild.name}`, iconURL: message.guild.iconURL() ? message.guild.iconURL({ dynamic: true }) : 'https://i.imgur.com/MNWYvup.gif' })
            
            message.channel.send({ embeds: [embed] }).catch((e) => console.log('Error al enviar mensaje: '+e))
      
        }

    }

}