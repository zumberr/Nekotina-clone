const nekoapi = require('cacao_nekoapi')
const { MessageEmbed } = require('discord.js');
module.exports =  {
    
    name: 'poke',
    aliases: ['molestar','fastidiar'],
    description: '¡Molestar!.',
    category: 'Interaccion',
    usage: '<prefix>poke [@user/id]',
  
    async run(client, message, args, Discord) { 

        let poke = await nekoapi.SFW.action_1.poke()
        let img = message.guild.members.resolve(message.mentions.users.first() || client.users.cache.get(args[0]));
   
        while (!poke || poke === null || poke === '' || poke === undefined) {
            
            poke = await nekoapi.SFW.action_1.poke()

        }
        
        if (!img || img.id === message.author.id) {

            const embed = new MessageEmbed()
            .setDescription(`**${message.author.username}** no me molestes >:v`)
            .setImage(poke.url)
            .setColor('RANDOM')
            .setTimestamp(new Date())
            .setFooter({ text: `${message.guild.name}`, iconURL: message.guild.iconURL() ? message.guild.iconURL({ dynamic: true }) : 'https://i.imgur.com/MNWYvup.gif' })

            message.channel.send({ embeds: [embed] }).catch((e) => console.log('Error al enviar mensaje: '+e))

        } else if (img.user.bot){
        
            return message.reply({ allowedMentions: { repliedUser: false}, embeds: [
        
                new MessageEmbed()
                .setAuthor({ name: message.author.tag, iconURL: message.author.displayAvatarURL({ dynamic: true}) })
                .setColor('RED')
                .setDescription(`Molesta a otro >:c`)
        
            ]}).catch((e) => console.log('Error al enviar mensaje: '+e))
        
        } else {

            const embed = new MessageEmbed()
            .setDescription(`**${message.author.username}** está fastidiando a **${img.user.username}** :u`)
            .setImage(poke.url)
            .setColor('RANDOM')
            .setTimestamp(new Date())
            .setFooter({ text: `${message.guild.name}`, iconURL: message.guild.iconURL() ? message.guild.iconURL({ dynamic: true }) : 'https://i.imgur.com/MNWYvup.gif' })

            message.channel.send({ embeds: [embed] }).catch((e) => console.log('Error al enviar mensaje: '+e))

        }

    }

}