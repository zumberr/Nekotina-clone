const { MessageEmbed } = require("discord.js")

module.exports = {
        name: 'sus',
    aliases: [],
    description: 'suspechoso..',
    category: 'Interaccion',
    usage: '<prefix>sus',
  
    async run(client, message, args, Discord) {
           try {
    return message.reply({
        embeds: [
            new MessageEmbed()
            .setColor("#fbd9ff")
            .setDescription ("")
            .setImage ('https://media.tenor.com/xlV5mZ_UcFYAAAAC/among-us-sus.gif')
]
    })
                  } catch (error) {
       console.log(`${error} || ${this.name} || ${message} || ${message.author} || ${message.guild.name}`)
        }
    }
}