const { MessageEmbed } = require('discord.js');
module.exports =  {
    
    name: 'think',
    aliases: ['pienso'],
    description: 'Piensas.',
    category: 'Interaccion',
    use: '<prefix>think | pienso',
  
    async run(client, message, args, Discord) { 

        var think = [

            'https://media.tenor.com/SJ7voMPwofMAAAAC/focus-what-does-this-mean.gif',
            'https://media.tenor.com/eAqD-5MDzFAAAAAC/mai-sakurajima-sakurajima-mai.gif',
            'https://media.tenor.com/sAv0KYdWIrUAAAAC/hmm-thinking.gif',
            'https://media.tenor.com/FqFi24NV4REAAAAC/aimoto-rinku-d4dj-first-mix.gif',
            'https://media.tenor.com/K3LslQdLo04AAAAd/inugami-korone-hololive.gif',
            'https://media.tenor.com/K3LslQdLo04AAAAd/inugami-korone-hololive.gif',
            'https://media.tenor.com/nqA9OzT3JzMAAAAC/anime-doubt.gif',
            
        
        ]

        let img = message.guild.members.resolve(message.mentions.users.first() || client.users.cache.get(args[0]));
        let ramdonthink = think[Math.floor(Math.random()*think.length)]
    
        while (!ramdonthink || ramdonthink === null || ramdonthink === '' || ramdonthink === undefined) {
            
            ramdonthink = think[Math.floor(Math.random()*think.length)]

        }
        
        if (!img || img.id === message.author.id) {
    
            const embed = new MessageEmbed()
            .setDescription(`**${message.author.username}** piensa.`)
            .setImage(ramdonthink)
            .setColor('RANDOM')
            .setTimestamp(new Date())
            .setFooter({ text: `${message.guild.name}`, iconURL: message.guild.iconURL() ? message.guild.iconURL({ dynamic: true }) : 'https://i.imgur.com/MNWYvup.gif' })

            message.channel.send({ embeds: [embed] });
    
        } else if (img.user.bot){
          
            return message.reply({ allowedMentions: { repliedUser: false }, embeds: [
          
                new MessageEmbed()
                .setAuthor({ name: message.author.tag, iconURL: message.author.displayAvatarURL({ dynamic: true}) })
                .setColor('RED')
                .setDescription(`No me hagas enfadar, ni a otros bots >~<`)
          
            ]}).catch((e) => console.log('Error al enviar mensaje: '+e))
          
        } else {
    
            const embed = new MessageEmbed()
            .setDescription(`**${message.author.username}** piensa a causa de **${img.user.username}** O.o`)
            .setImage(ramdonthink)
            .setColor('RANDOM')
            .setTimestamp(new Date())
            .setFooter({ text: `${message.guild.name}`, iconURL: message.guild.iconURL() ? message.guild.iconURL({ dynamic: true }) : 'https://i.imgur.com/MNWYvup.gif' })

            message.channel.send({ embeds: [embed] }).catch((e) => console.log('Error al enviar mensaje: '+e))
      
        }

    }

}