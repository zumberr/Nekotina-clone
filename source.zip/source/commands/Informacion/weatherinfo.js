const types = { Monday: "Lunes", Tuesday: "Martes", Wednesday: "Miércoles", Thursday: "Jueves", Friday: "Viernes", Saturday: "Sábado", Sunday: "Domingo"}
const axios = require("axios").default;
const { MessageEmbed } = require("discord.js");

module.exports = {
    name: "weatherinfo",
    usage: "weatherinfo | weather <cuidad>",
    aliases: ["weather"],
    cooldown: 2,
    example: "weatherinfo | weather Caracas, Venezuela",
    ownerOnly: false,
    UserPerms: ["SEND_MESSAGES"],
    ClientPerms: ["SEND_MESSAGES", "EMBED_LINKS"],
    description: "Obtener información del clima de algun estado.",
    async run(client, message, args, prefix) {
   try {
    let state;
    state = args.slice(0).join(" ");

    if(!state) {
        return message.reply({
            embeds: [new MessageEmbed()
            .setColor("#fbd9ff")
            .setAuthor({ name: "Error Code: 3002" })
            .setDescription(`No se ha proporcionado el nombre del estado.\n\nUso correcto del comando:\n\` ${this.usage} \``)
            ]
        })
    } else {
        await message.reply({
            embeds: [new MessageEmbed()
            .setColor("#fbd9ff")
            .setDescription(`Espere mientras se obtiene la informaciónsobre el clima...`)
            ]
        }).then(async(m) => {
                await axios.get(`https://api.popcat.xyz/weather?q=${encodeURIComponent(state)}`).then(response => {
                    return m.edit({
                        embeds: [new MessageEmbed()
                        .setColor("#fbd9ff")
                        .setAuthor({ name: `Información de: ${response.data[0].location.name}` })
                        .setThumbnail(response.data[0].current.imageUrl)
                        .setDescription(`Nombre la localización: ${response.data[0].location.name}
Tipo de formato del clima de la localización: ${response.data[0].location.degreetype}
Día actual en la localización: ${types[response.data[0].current.day]}
Zona horaria de la localización: ${response.data[0].location.timezone}
Humedad actual en la localización: ${response.data[0].current.humidity}%
Temperatura actual de la localización: ${response.data[0].location.timezone}
Fecha completa actual de la localización: ${response.data[0].current.date}
Velocidad actual del viento en la localización: ${response.data[0].current.windspeed}
Texto meteorológico del clima actual en la localización: ${response.data[0].current.skytext}
Código meteorológico del clima actual en la localización: ${response.data[0].current.skycode}
Punto de observación del clima en la localización: ${response.data[0].current.observationpoint}
Ultimá hora de la observación del clima en la localización: ${response.data[0].current.observationtime}`)
                        .addField("Pronósticos del clima de Mañana", `Código meteorológico del clima: ${response.data[0].forecast[0].skycodeday}
Temperatura mas baja del clima: ${response.data[0].forecast[0].low}
Temperatura mas alta del clima: ${response.data[0].forecast[0].high}`)
                        ]
                    })
                }).catch(() => {
                    return m.edit({
                        embeds: [new MessageEmbed()
                        .setColor("#fbd9ff")
                        .setAuthor({ name: "Error Code: 6271" })
                        .setDescription("Ha ocurrido un error al intentar obtener la información o no se han encontrado resultados a tu búsqueda.")
                        ]
                    })
                })
            })
        }    
    } catch (error) {
       console.log(`${error} || ${this.name} || ${message} || ${message.author} || ${message.guild.name}`)
        }
    }
}