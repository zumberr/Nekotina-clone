const flagName = {"DISCORD_EMPLOYEE": "Empleado de Discord", "DISCORD_PARTNER": "Socio de Discord", "BUGHUNTER_LEVEL_1": "Cazador de bugs (Nivel 1)", "BUGHUNTER_LEVEL_2": "Cazador de bugs (Nivel 2)", "HYPESQUAD_EVENTS": "Coordinador de eventos del HypeSquad", "HOUSE_BRAVERY": "Bravery del HypeSquad", "HOUSE_BRILLIANCE": "Brilliance del HypeSquad", "HOUSE_BALANCE": "Balance del HypeSquad", "TEAM_USER": "Equipo", "SYSTEM": "Sistema", "VERIFIED_BOT": "Bot verificado", "VERIFIED_DEVELOPER": "Desarrollador verificado"}
const statusName = {"online": "Conectado", "idle": "Ausente", "dnd": "No molestar"}
const moment = require("moment")
const database = require("quick.db")
const { MessageEmbed } = require("discord.js")

module.exports = {
    name: "userinfo",
    usage: "userinfo | info <@member | memberID | MessageMember>",
    aliases: ["info"],
    example: "userinfo | info <@usuario#1010 | 123456789123456789>",
    ownerOnly: false,
    UserPerms: ["SEND_MESSAGES"],
    ClientPerms: ["SEND_MESSAGES", "EMBED_LINKS"],
    description: "Obtener información de algun usuario mencionado.",
    async run(client, message, args, prefix) {
   try {
    let banner, member, memberFlags, memberStatus, memberActivity, acknowledgements;
    member = await message.mentions.members.first() || message.guild.members.cache.get(args[0]) || message.member;
    memberFlags = await member.user.flags?.toArray();
    acknowledgements = "No tiene una Identificación.";

    if(member.id === message.guild.ownerId) {
        acknowledgements = "Dueño/Propietario del servidor.";
    }
    if(!member.presence || member.presence.status == "offline") {
        memberActivity = "Desconectado/Invisible.";
    } else { 
        memberActivity = `${statusName[member.presence.status]}`;
    }

    if(database.has(`afk_${message.guild.id}_${member.id}`)) {
        let check = database.get(`afk_${message.guild.id}_${member.id}`);
        memberStatus = `Razón del AFK: ${check.reason}\nFecha de creacion del AFK: <t:${check.timestamp}:R>`;
    } else {
        memberStatus = "El miembro no tiene el estado AFK actualmente.";
    }

    async function getUserBannerUrl(userId) {
        const user = await client.users.fetch(userId);
        return user.banner ? `https://cdn.discordapp.com/banners/${userId}/${user.banner}.${user.banner.startsWith("a_") ? "gif" : "png"}?size=4096` : null;
    }
    banner = await getUserBannerUrl(member.id, {
        dynamic: true,
        size: 4096
    })

    return message.reply({
        embeds: [new MessageEmbed()
        .setColor("#fbd9ff")
        .setAuthor({ name: `Información de ${member.user.tag}`, url: `${member.displayAvatarURL({ dynamic: true, format: "png", size: 4096 })}` })
        .setThumbnail(`${member.displayAvatarURL({ dynamic: true, format: "png", size: 4096 })}`)
        .setDescription(`Nombre del usuario: ${member.user.username}
Perfil/Cuenta de usuario: ${member}
Tipo de Cuenta de usuario: ${member.user.bot ? "Bot de Discord." : "Miembro de Discord."}
Discriminador del usuario: #${member.user.discriminator}
Identificación/ID del usuario: ${member.user.id}
Cuenta del Sistema de Discord: ${member.user.system ? "Cuenta Administrada por Discord." : "Cuenta Administrada por un Usuario."}

**Actividad del usuario**
Estado personalizado: ${member.presence?.activities[0]?.type == "CUSTOM" ? member.presence?.activities[0]?.state : "El usuario no tiene un estado personalizado."}
Estado del usuario: ${memberActivity}
Estado AFK del usuario: ${memberStatus}
 
**Emblemas del usuario**
${memberFlags?.length ? memberFlags.map(flag => flagName[flag]).join(", ") : `${member} no tiene un emblema de Discord.`}
        
**Información secundaria**
Member/Server Booster: ${member.premiumSince || "El usuario no es booster del servidor."}
Avatar del usuario: [Click Aquí](${member.displayAvatarURL({ dynamic: true, format: "png", size: 4096 })})
Banner del usuario: ${banner ? `[Click Aquí](${banner})` : "El usuario no tiene un banner personalizado."}
Nickname del usuario: ${member.nickname || "El usuario no tiene un nickname."}
Fecha de Entrada del usuario: <t:${Math.floor(member.joinedTimestamp / 1000)}:R>
Fecha de Creación de la Cuenta: <t:${Math.floor(member.user.createdTimestamp / 1000)}:R>
        
**Roles del usuario**
${member.roles.cache.sort((a, b) => b.position - a.position).filter((z) => z.name !== "@everyone").map(role => role.toString()).join(" ") || "El usuario no tiene ningun rol agregado actualmente."}

**Identificación en el Servidor**
${acknowledgements}`)
        ]
    })
    } catch (error) {
       console.log(`${error} || ${this.name} || ${message} || ${message.author} || ${message.guild.name}`)
        }
    }
}