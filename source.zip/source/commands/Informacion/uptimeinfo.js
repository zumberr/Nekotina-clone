const { MessageEmbed } = require("discord.js");

module.exports = {
    name: "uptimeinfo",
    usage: "uptimeinfo | uptime <No Args>",
    aliases: ["uptime"],
    cooldown: 2,
    example: "uptimeinfo | uptime <No Args>",
    ownerOnly: false,
    UserPerms: ["SEND_MESSAGES"],
    ClientPerms: ["SEND_MESSAGES", "EMBED_LINKS"],
    description: "Obtener información sobre cuanto tiempo lleva encendido el cliente.",
    async run(client, message, args, prefix) {
   try {
    let days, hours, minutes, seconds;
    days = ~~(client.uptime / 86400000)
    hours = ~~(client.uptime / 3600000) % 24;
    minutes = ~~(client.uptime / 60000) % 60;
    seconds = ~~(client.uptime / 1000) % 60;

    return message.reply({
        embeds: [new MessageEmbed()
        .setColor("#fbd9ff")
        .setDescription(`Lena lleva ${days} día(s), ${hours} horas, ${minutes} minutos, ${seconds} segundos encendido.`)
        ]
    })
   } catch(error) {
        return console.error(`${error} || ${this.name} || ${message} || ${message.author} || ${message.guild.name}`)
        }
    }
}