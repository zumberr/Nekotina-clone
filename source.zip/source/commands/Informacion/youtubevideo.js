const { get } = require("axios").default;
const { MessageEmbed } = require("discord.js")

module.exports = {
    name: "youtubevideo",
    usage: "youtubevideo | ytvideo <búsqueda>",
    aliases: ["ytvideo"],
    cooldown: 0,
    example: "youtubevideo | ytvideo The Big Black",
    ownerOnly: false,
    UserPerms: ["SEND_MESSAGES"],
    ClientPerms: ["SEND_MESSAGES", "EMBED_LINKS"],
    description: "Buscar información de un video de YouTube en especifico.",
    async run(client, message, args, prefix) {
   try {
    let search, request;
    search = args.slice(0).join("+")
    request = await get(`https://serpapi.com/search.json?engine=youtube&search_query=${search}&api_key=b0ee45e83f900c6d2f9a4cdb2736d1e1692a602fbbbe1c9cbf64c73e57a071e8`).then((res) => res.data.video_results[0]).catch(() => {})
    
    if(!search) {
        return message.reply({
            embeds: [new MessageEmbed()
            .setColor("#fbd9ff")
            .setAuthor({ name: "Error Code: 6616" })
            .setDescription(`No se ha proporcionado la búsqueda.\n\nUso correcto del comando:\n\` ${this.usage} \``)
            ]
        })
    } else try {
        return message.reply({
            embeds: [new MessageEmbed()
            .setColor("#fbd9ff")
            .setThumbnail(request.thumbnail.static)
            .setAuthor({ name: `Esto ha sido lo que he encontrado de: ${args.slice(0).join(" ")}`, url: `${request.link}` })
            .setDescription(`Autor del video: ${request.channel.name}
Link/URL del video: [Click Aquí](${request.link})
Titulo del video: ${request.title}
Descripción del video: ${request.description}
Vistas del video: ${request.views}
Duración del video: ${request.length}
Posición del video: ${request.position_on_page}
Fecha de publicación del video: ${request.published_date}`)
            ]
        })
    } catch(error) {
        return message.reply({
            embeds: [new MessageEmbed()
            .setColor("#fbd9ff")
            .setAuthor({ name: "Error Code: 5514" })
            .setDescription(`No se han encontrado resultados a tu búsqueda.`)
            ]
        })
    }
    } catch (error) {
       console.log(`${error} || ${this.name} || ${message} || ${message.author} || ${message.guild.name}`)
        }
    }
}