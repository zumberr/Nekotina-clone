const {
    Message,
    Client,
    MessageEmbed,
    Permissions
} = require("discord.js");

module.exports = {
    name: "stoprepeat",
    aliases: ["strep"],
    description: "Detener la repetición de música",
    usage: "<prefix>stoprepeat",
    /**
     *
     * @param {Client} client
     * @param {Message} message
     * @param {String[]} args
     */
     async run (client, message, args)  {
        client.player.getQueue(message.guild.id).setRepeatMode(RepeatMode.DISABLED);
        // obtiene la cancion
        let song = await client.player.play(message.guild.id);
        message.channel.send("<:emoji_19:1045823671350087791>", `${song.name} no será repetida más!`);
    },
};