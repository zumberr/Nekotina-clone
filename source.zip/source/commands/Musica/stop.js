const {
    Message,
    Client,
    MessageEmbed,
    Permissions
} = require("discord.js");

module.exports = {
    name: "stop",
    description: "Paro todas las canciones",
    usage: "<prefix>stop",
    example: "*stop",
    /**
     *
     * @param {Client} client
     * @param {Message} message
     * @param {String[]} args
     */
    async run (client, message, args)  {
        client.player.getQueue(message.guild.id).stop();
        message.channel.send('<:emoji_19:1045823671350087791> He detenido todas las canciones y limpiado la cola!');
    },
};