const {
    Message,
    Client,
    MessageEmbed,
    Permissions
} = require("discord.js");

module.exports = {
    name: "resume",
    description: "Resume la cancion",
    usage: "<prefix>resume",
    example: "*resume",
    /**
     *
     * @param {Client} client
     * @param {Message} message
     * @param {String[]} args
     */
     async run (client, message, args) {
        let song = await client.player.getQueue(message.guild.id).setPaused(false);
        message.channel.send("<:emoji_19:1045823671350087791>", `**${song.name}** ha sido resumida!`);
    },
};