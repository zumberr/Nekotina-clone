const {
    Message,
    Client,
    MessageEmbed,
    Permissions
} = require("discord.js");

module.exports = {
    name: "skip",
    description: "Salta una cancion",
    usage: "<prefix>skip",
    example: "*skip",
    /**
     *
     * @param {Client} client
     * @param {Message} message
     * @param {String[]} args
     */
    run: async (client, message, args) => {
        let song = await client.player.getQueue(message.guild.id).skip();
        message.channel.send("<:emoji_19:1045823671350087791>", `**${song.name}** ha sido saltada!`);
    },
};