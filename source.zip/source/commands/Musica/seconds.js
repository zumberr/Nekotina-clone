const {
    Message,
    Client,
    MessageEmbed,
    Permissions
} = require("discord.js");

module.exports = {
    name: "seconds",
    aliases: ["avance"],
    description: "Avanza la cancion por segundos",
    usage: "<prefix>seconds <segundos>",
    example: "*seconds 15",
    /**
     *
     * @param {Client} client
     * @param {Message} message
     * @param {String[]} args
     */
    async run (client, message, args)  {
        client.player.getQueue(message.guild.id).seek(parseInt(args[0]) * 1000);

        message.channel.send(`La música ha avanzado \`${args[0]} segundos\``)
    },
};