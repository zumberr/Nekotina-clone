const { ContextMenuInteraction, Client, MessageEmbed } = require('discord.js');

module.exports = {
	name: 'getavatar',
	type: 'USER',
	/**
	 * @param {Client} client
	 * @param {ContextMenuInteraction} interaction
	 * @param {String[]} args
	 */
	run: async (client, interaction, args) => {
		const avatar = interaction.user.displayAvatarURL({
			dynamic: true,
			size: 1024,
		});
		const embed = new MessageEmbed()
			.setTitle(`avatar de ${interaction.user.username}`)
			.setImage(avatar)
			.setColor('BLUE')
			.setTimestamp();

		interaction.followUp({ embeds: [embed] });
	},
};
